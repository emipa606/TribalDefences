﻿using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace TribalDefences
{
	// Token: 0x02000002 RID: 2
	public class Alert_NeedDefenses : Alert
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public Alert_NeedDefenses()
		{
			this.defaultLabel = Translator.Translate("NeedDefenses");
			this.defaultExplanation = Translator.Translate("NeedDefensesDesc");
			this.defaultPriority = 1;
		}

		// Token: 0x06000002 RID: 2 RVA: 0x00002084 File Offset: 0x00000284
		public override AlertReport GetReport()
		{
			bool flag = GenDate.DaysPassed < 2 || GenDate.DaysPassed > 5;
			AlertReport result;
			if (flag)
			{
				result = false;
			}
			else
			{
				List<Map> maps = Find.Maps;
				for (int i = 0; i < maps.Count; i++)
				{
					bool flag2 = this.NeedDefenses(maps[i]);
					if (flag2)
					{
						return true;
					}
				}
				result = false;
			}
			return result;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x000020FC File Offset: 0x000002FC
		private bool NeedDefenses(Map map)
		{
			bool flag = !map.IsPlayerHome;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				result = !GenCollection.Any<Building>(map.listerBuildings.allBuildingsColonist, (Building b) => (b.def.building != null && (b.def.building.IsTurret || b.def.building.isTrap)) || b.def == ThingDefOf.Sandbags || b.def == ThingDefOf.EarthenMounds);
			}
			return result;
		}
	}
}
