﻿using System;
using RimWorld;
using Verse;

namespace TribalDefences
{
	// Token: 0x02000003 RID: 3
	[DefOf]
	public static class ThingDefOf
	{
		// Token: 0x04000001 RID: 1
		public static ThingDef EarthenMounds;

		// Token: 0x04000002 RID: 2
		public static ThingDef Sandbags;
	}
}
